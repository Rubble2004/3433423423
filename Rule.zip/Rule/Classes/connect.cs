﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rule.Classes
{
    internal class connect
    {
        public static model.turagentsEntities modelbd;

    }
}
